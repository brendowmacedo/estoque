
# Controle de Estoque - Flutter Web

Este é um aplicativo de controle de estoque desenvolvido em **Flutter Web**.
Você pode rodar localmente ou publicar em serviços como **Vercel**, **Firebase Hosting**, ou **GitHub Pages**.

## 🚀 Recursos

- Adicionar/remover produtos
- Visualização da quantidade em estoque
- Alerta visual de estoque baixo
- Interface simples e responsiva

## ▶️ Rodar localmente

```bash
flutter pub get
flutter run -d chrome
```

## 🌍 Publicar com Vercel

```bash
flutter build web
cd build/web
vercel
```

## 📁 Estrutura do Projeto

- `lib/main.dart` — Código principal do aplicativo
- `pubspec.yaml` — Dependências do projeto
- `build/web/` — Código gerado para publicar (gerado após `flutter build web`)
